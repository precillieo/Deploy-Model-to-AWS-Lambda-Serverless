
# THIS FILE IS GENERATED FROM SCIPY SETUP.PY
short_version = '1.6.1'
version = '1.6.1'
full_version = '1.6.1'
git_revision = '5ab7426247900db9de856e790b8bea1bd71aec49'
release = True

if not release:
    version = full_version
